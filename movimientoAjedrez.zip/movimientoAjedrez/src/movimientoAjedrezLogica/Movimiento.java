package movimientoAjedrezLogica;

public interface Movimiento {
	
	public void hallarCasillasDisponibles();

}
